#error "The correct implementation must be chosen based on the `uintmax_t' type"
